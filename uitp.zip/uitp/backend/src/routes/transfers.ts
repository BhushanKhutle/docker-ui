import { Router, Response } from 'express';
import pool from '../db/pool';
import { authenticate, requireRole, AuthRequest } from '../middleware/auth';
import { decrypt } from '../utils/encryption';
import { sshService } from '../services/sshService';
import { getWebSocketServer } from '../websocket/wsServer';

const router = Router();
router.use(authenticate);

// GET /transfers (history)
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { limit = 50, offset = 0, status } = req.query;
    let query = `
      SELECT t.*,
        sn.name as source_node_name, sn.ip_address as source_node_ip,
        dn.name as destination_node_name, dn.ip_address as destination_node_ip,
        sc.name as source_cluster_name, sc.environment as source_environment,
        dc.name as destination_cluster_name, dc.environment as destination_environment,
        u.username as initiated_by_username
      FROM transfers t
      LEFT JOIN nodes sn ON sn.id = t.source_node_id
      LEFT JOIN nodes dn ON dn.id = t.destination_node_id
      LEFT JOIN clusters sc ON sc.id = t.source_cluster_id
      LEFT JOIN clusters dc ON dc.id = t.destination_cluster_id
      LEFT JOIN users u ON u.id = t.initiated_by
      WHERE 1=1
    `;
    const params: any[] = [];
    if (status) {
      params.push(status);
      query += ` AND t.status = $${params.length}`;
    }
    params.push(limit, offset);
    query += ` ORDER BY t.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const result = await pool.query(query, params);
    const countResult = await pool.query('SELECT COUNT(*) FROM transfers' + (status ? ` WHERE status='${status}'` : ''));
    res.json({ transfers: result.rows, total: parseInt(countResult.rows[0].count) });
  } catch {
    res.status(500).json({ error: 'Failed to fetch transfer history' });
  }
});

// POST /transfers - initiate transfer
router.post('/', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { image_id, source_node_id, destination_node_ids } = req.body;
    if (!image_id || !source_node_id || !destination_node_ids?.length) {
      res.status(400).json({ error: 'image_id, source_node_id, destination_node_ids required' });
      return;
    }

    const imageResult = await pool.query('SELECT * FROM images WHERE id=$1', [image_id]);
    if (!imageResult.rows[0]) {
      res.status(404).json({ error: 'Image not found' });
      return;
    }
    const image = imageResult.rows[0];

    const sourceResult = await pool.query(
      'SELECT n.*, c.id as cluster_id FROM nodes n LEFT JOIN clusters c ON c.id=n.cluster_id WHERE n.id=$1',
      [source_node_id]
    );
    if (!sourceResult.rows[0]) {
      res.status(404).json({ error: 'Source node not found' });
      return;
    }
    const sourceNode = sourceResult.rows[0];

    // Create transfer records for each destination
    const transferIds: string[] = [];
    for (const destNodeId of destination_node_ids) {
      const destResult = await pool.query(
        'SELECT n.*, c.id as cluster_id FROM nodes n LEFT JOIN clusters c ON c.id=n.cluster_id WHERE n.id=$1',
        [destNodeId]
      );
      if (!destResult.rows[0]) continue;
      const destNode = destResult.rows[0];

      const transferResult = await pool.query(
        `INSERT INTO transfers (image_id, image_name, source_node_id, destination_node_id,
          source_cluster_id, destination_cluster_id, status, initiated_by)
         VALUES ($1,$2,$3,$4,$5,$6,'pending',$7) RETURNING id`,
        [image_id, image.full_name, source_node_id, destNodeId,
          sourceNode.cluster_id, destNode.cluster_id, req.user!.id]
      );
      transferIds.push(transferResult.rows[0].id);
    }

    // Execute transfers asynchronously
    for (let i = 0; i < transferIds.length; i++) {
      const transferId = transferIds[i];
      const destNodeId = destination_node_ids[i];

      executeTransfer(transferId, image.full_name, sourceNode, destNodeId, req.user!.id);
    }

    res.status(202).json({ message: 'Transfers initiated', transfer_ids: transferIds });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to initiate transfer: ${err.message}` });
  }
});

// GET /transfers/:id
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query(
      `SELECT t.*,
        sn.name as source_node_name, dn.name as destination_node_name,
        sc.name as source_cluster_name, dc.name as destination_cluster_name
       FROM transfers t
       LEFT JOIN nodes sn ON sn.id=t.source_node_id
       LEFT JOIN nodes dn ON dn.id=t.destination_node_id
       LEFT JOIN clusters sc ON sc.id=t.source_cluster_id
       LEFT JOIN clusters dc ON dc.id=t.destination_cluster_id
       WHERE t.id=$1`,
      [req.params.id]
    );
    if (!result.rows[0]) {
      res.status(404).json({ error: 'Transfer not found' });
      return;
    }
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: 'Failed to fetch transfer' });
  }
});

// POST /transfers/:id/cancel
router.post('/:id/cancel', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query(
      `UPDATE transfers SET status='cancelled', completed_at=NOW()
       WHERE id=$1 AND status='pending' RETURNING id`,
      [req.params.id]
    );
    if (!result.rows[0]) {
      res.status(400).json({ error: 'Transfer cannot be cancelled (not pending)' });
      return;
    }
    res.json({ message: 'Transfer cancelled' });
  } catch {
    res.status(500).json({ error: 'Failed to cancel transfer' });
  }
});

async function executeTransfer(
  transferId: string,
  imageName: string,
  sourceNode: any,
  destNodeId: string,
  userId: string
): Promise<void> {
  const wss = getWebSocketServer();
  const startTime = Date.now();

  const broadcast = (type: string, data: any) => {
    wss?.broadcast({ type, transferId, ...data });
  };

  try {
    await pool.query(
      "UPDATE transfers SET status='running', started_at=NOW() WHERE id=$1",
      [transferId]
    );
    broadcast('transfer:start', { imageName });

    const destResult = await pool.query('SELECT * FROM nodes WHERE id=$1', [destNodeId]);
    const destNode = destResult.rows[0];
    if (!destNode) throw new Error('Destination node not found');

    const sourceConfig = {
      host: sourceNode.ip_address,
      port: sourceNode.ssh_port,
      username: sourceNode.username,
      password: sourceNode.password_encrypted ? decrypt(sourceNode.password_encrypted) : undefined,
      privateKey: sourceNode.ssh_key_encrypted ? decrypt(sourceNode.ssh_key_encrypted) : undefined,
    };

    const destConfig = {
      host: destNode.ip_address,
      port: destNode.ssh_port,
      username: destNode.username,
      password: destNode.password_encrypted ? decrypt(destNode.password_encrypted) : undefined,
      privateKey: destNode.ssh_key_encrypted ? decrypt(destNode.ssh_key_encrypted) : undefined,
    };

    let logs = '';
    await sshService.transferImage(
      sourceConfig, sourceNode.node_type,
      destConfig, destNode.node_type,
      imageName,
      (log) => {
        logs += log + '\n';
        broadcast('transfer:log', { log });
      }
    );

    const duration = Math.round((Date.now() - startTime) / 1000);
    await pool.query(
      `UPDATE transfers SET status='success', completed_at=NOW(), duration_seconds=$1, logs=$2 WHERE id=$3`,
      [duration, logs, transferId]
    );

    // Update node_images
    const imageResult = await pool.query(
      'SELECT id FROM images WHERE full_name=$1', [imageName]
    );
    if (imageResult.rows[0]) {
      await pool.query(
        `INSERT INTO node_images (node_id, image_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`,
        [destNodeId, imageResult.rows[0].id]
      );
    }

    broadcast('transfer:complete', { duration, status: 'success' });
  } catch (err: any) {
    const duration = Math.round((Date.now() - startTime) / 1000);
    await pool.query(
      `UPDATE transfers SET status='failed', completed_at=NOW(), duration_seconds=$1, error_message=$2 WHERE id=$3`,
      [duration, err.message, transferId]
    );
    broadcast('transfer:error', { error: err.message });
  }
}

export default router;
