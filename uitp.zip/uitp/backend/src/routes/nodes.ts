import { Router, Response } from 'express';
import pool from '../db/pool';
import { authenticate, requireRole, AuthRequest } from '../middleware/auth';
import { encrypt, decrypt } from '../utils/encryption';
import { sshService } from '../services/sshService';

const router = Router();
router.use(authenticate);

// GET /nodes
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { cluster_id } = req.query;
    let query = `
      SELECT n.id, n.cluster_id, c.name as cluster_name, c.environment,
        n.name, n.ip_address, n.ssh_port, n.username, n.auth_type, n.node_type,
        n.is_active, n.last_sync_at, n.created_at,
        COUNT(DISTINCT ni.image_id) as image_count
      FROM nodes n
      LEFT JOIN clusters c ON c.id = n.cluster_id
      LEFT JOIN node_images ni ON ni.node_id = n.id
      WHERE n.is_active = true
    `;
    const params: any[] = [];
    if (cluster_id) {
      params.push(cluster_id);
      query += ` AND n.cluster_id = $${params.length}`;
    }
    query += ' GROUP BY n.id, c.name, c.environment ORDER BY c.environment, c.name, n.name';
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: 'Failed to fetch nodes' });
  }
});

// GET /nodes/:id
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query(
      `SELECT n.*, c.name as cluster_name, c.environment
       FROM nodes n LEFT JOIN clusters c ON c.id = n.cluster_id
       WHERE n.id = $1`,
      [req.params.id]
    );
    if (!result.rows[0]) {
      res.status(404).json({ error: 'Node not found' });
      return;
    }
    const node = result.rows[0];
    delete node.password_encrypted;
    delete node.ssh_key_encrypted;
    res.json(node);
  } catch {
    res.status(500).json({ error: 'Failed to fetch node' });
  }
});

// POST /nodes
router.post('/', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { cluster_id, name, ip_address, ssh_port, username, auth_type, password, ssh_key, node_type } = req.body;
    if (!cluster_id || !name || !ip_address || !username) {
      res.status(400).json({ error: 'cluster_id, name, ip_address, and username are required' });
      return;
    }
    const encPwd = password ? encrypt(password) : null;
    const encKey = ssh_key ? encrypt(ssh_key) : null;
    const result = await pool.query(
      `INSERT INTO nodes (cluster_id, name, ip_address, ssh_port, username, auth_type, password_encrypted, ssh_key_encrypted, node_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, cluster_id, name, ip_address, ssh_port, username, auth_type, node_type, is_active, created_at`,
      [cluster_id, name, ip_address, ssh_port || 22, username, auth_type || 'password', encPwd, encKey, node_type || 'docker']
    );
    res.status(201).json(result.rows[0]);
  } catch {
    res.status(500).json({ error: 'Failed to create node' });
  }
});

// PUT /nodes/:id
router.put('/:id', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, ip_address, ssh_port, username, auth_type, password, ssh_key, node_type } = req.body;
    const encPwd = password ? encrypt(password) : null;
    const encKey = ssh_key ? encrypt(ssh_key) : null;
    const result = await pool.query(
      `UPDATE nodes SET name=$1, ip_address=$2, ssh_port=$3, username=$4, auth_type=$5,
        password_encrypted=COALESCE($6, password_encrypted),
        ssh_key_encrypted=COALESCE($7, ssh_key_encrypted),
        node_type=$8, updated_at=NOW()
       WHERE id=$9 RETURNING id, name, ip_address, ssh_port, username, auth_type, node_type, is_active`,
      [name, ip_address, ssh_port || 22, username, auth_type || 'password', encPwd, encKey, node_type || 'docker', req.params.id]
    );
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: 'Failed to update node' });
  }
});

// DELETE /nodes/:id
router.delete('/:id', requireRole('admin'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    await pool.query('UPDATE nodes SET is_active=false WHERE id=$1', [req.params.id]);
    res.json({ message: 'Node deleted' });
  } catch {
    res.status(500).json({ error: 'Failed to delete node' });
  }
});

// POST /nodes/:id/test-connection
router.post('/:id/test-connection', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query('SELECT * FROM nodes WHERE id=$1', [req.params.id]);
    const node = result.rows[0];
    if (!node) {
      res.status(404).json({ error: 'Node not found' });
      return;
    }
    const config = {
      host: node.ip_address,
      port: node.ssh_port,
      username: node.username,
      password: node.password_encrypted ? decrypt(node.password_encrypted) : undefined,
      privateKey: node.ssh_key_encrypted ? decrypt(node.ssh_key_encrypted) : undefined,
    };
    const ok = await sshService.testConnection(config);
    res.json({ success: ok, message: ok ? 'Connection successful' : 'Connection failed' });
  } catch {
    res.status(500).json({ error: 'Connection test failed' });
  }
});

// POST /nodes/:id/sync
router.post('/:id/sync', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const nodeResult = await pool.query('SELECT * FROM nodes WHERE id=$1', [req.params.id]);
    const node = nodeResult.rows[0];
    if (!node) {
      res.status(404).json({ error: 'Node not found' });
      return;
    }
    const config = {
      host: node.ip_address,
      port: node.ssh_port,
      username: node.username,
      password: node.password_encrypted ? decrypt(node.password_encrypted) : undefined,
      privateKey: node.ssh_key_encrypted ? decrypt(node.ssh_key_encrypted) : undefined,
    };

    const images = await sshService.listImages(config, node.node_type);

    // Upsert images and node_images
    let synced = 0;
    for (const img of images) {
      if (!img.repository || !img.tag) continue;
      const imgResult = await pool.query(
        `INSERT INTO images (repository, tag, digest, size_bytes, created_date)
         VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (repository, tag) DO UPDATE SET
           digest=EXCLUDED.digest, size_bytes=EXCLUDED.size_bytes, updated_at=NOW()
         RETURNING id`,
        [img.repository, img.tag, img.digest || null, img.size_bytes || null, img.created_date || null]
      );
      const imageId = imgResult.rows[0].id;
      await pool.query(
        `INSERT INTO node_images (node_id, image_id, image_id_on_node)
         VALUES ($1,$2,$3)
         ON CONFLICT (node_id, image_id) DO UPDATE SET discovered_at=NOW()`,
        [node.id, imageId, img.image_id_on_node || null]
      );
      synced++;
    }

    // Remove images no longer present
    const currentImageNames = images.map(i => `${i.repository}:${i.tag}`);
    if (currentImageNames.length > 0) {
      await pool.query(
        `DELETE FROM node_images WHERE node_id=$1 AND image_id NOT IN (
          SELECT id FROM images WHERE full_name = ANY($2)
        )`,
        [node.id, currentImageNames]
      );
    } else {
      await pool.query('DELETE FROM node_images WHERE node_id=$1', [node.id]);
    }

    await pool.query('UPDATE nodes SET last_sync_at=NOW() WHERE id=$1', [node.id]);
    res.json({ message: `Synced ${synced} images`, count: synced });
  } catch (err: any) {
    res.status(500).json({ error: `Sync failed: ${err.message}` });
  }
});

export default router;
