import { Router, Response } from 'express';
import pool from '../db/pool';
import { authenticate, requireRole, AuthRequest } from '../middleware/auth';

const router = Router();
router.use(authenticate);

// GET /clusters
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query(`
      SELECT c.*, 
        COUNT(DISTINCT n.id) as node_count,
        COUNT(DISTINCT ni.image_id) as image_count
      FROM clusters c
      LEFT JOIN nodes n ON n.cluster_id = c.id AND n.is_active = true
      LEFT JOIN node_images ni ON ni.node_id = n.id
      WHERE c.is_active = true
      GROUP BY c.id
      ORDER BY c.environment, c.name
    `);
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: 'Failed to fetch clusters' });
  }
});

// GET /clusters/:id
router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const result = await pool.query(
      `SELECT c.*, COUNT(DISTINCT n.id) as node_count
       FROM clusters c
       LEFT JOIN nodes n ON n.cluster_id = c.id AND n.is_active = true
       WHERE c.id = $1 GROUP BY c.id`,
      [req.params.id]
    );
    if (!result.rows[0]) {
      res.status(404).json({ error: 'Cluster not found' });
      return;
    }
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: 'Failed to fetch cluster' });
  }
});

// POST /clusters
router.post('/', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, environment, description } = req.body;
    if (!name || !environment) {
      res.status(400).json({ error: 'Name and environment required' });
      return;
    }
    const result = await pool.query(
      'INSERT INTO clusters (name, environment, description, created_by) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, environment, description, req.user!.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create cluster' });
  }
});

// PUT /clusters/:id
router.put('/:id', requireRole('admin', 'operator'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { name, environment, description } = req.body;
    const result = await pool.query(
      `UPDATE clusters SET name=$1, environment=$2, description=$3, updated_at=NOW()
       WHERE id=$4 RETURNING *`,
      [name, environment, description, req.params.id]
    );
    if (!result.rows[0]) {
      res.status(404).json({ error: 'Cluster not found' });
      return;
    }
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: 'Failed to update cluster' });
  }
});

// DELETE /clusters/:id
router.delete('/:id', requireRole('admin'), async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    await pool.query('UPDATE clusters SET is_active=false WHERE id=$1', [req.params.id]);
    res.json({ message: 'Cluster deleted' });
  } catch {
    res.status(500).json({ error: 'Failed to delete cluster' });
  }
});

export default router;
