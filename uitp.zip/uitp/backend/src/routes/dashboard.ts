import { Router, Response } from 'express';
import pool from '../db/pool';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
router.use(authenticate);

router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const [clusters, nodes, images, transfers, recentTransfers] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM clusters WHERE is_active=true'),
      pool.query('SELECT COUNT(*) FROM nodes WHERE is_active=true'),
      pool.query('SELECT COUNT(*) FROM node_images'),
      pool.query(`
        SELECT
          COUNT(*) FILTER (WHERE status='success') as success,
          COUNT(*) FILTER (WHERE status='failed') as failed,
          COUNT(*) FILTER (WHERE status='running') as running,
          COUNT(*) FILTER (WHERE status='pending') as pending
        FROM transfers
        WHERE created_at > NOW() - INTERVAL '24 hours'
      `),
      pool.query(`
        SELECT t.id, t.image_name, t.status, t.created_at, t.duration_seconds,
          sn.name as source_node, dn.name as dest_node,
          sc.name as source_cluster, dc.name as dest_cluster,
          sc.environment as source_env, dc.environment as dest_env
        FROM transfers t
        LEFT JOIN nodes sn ON sn.id=t.source_node_id
        LEFT JOIN nodes dn ON dn.id=t.destination_node_id
        LEFT JOIN clusters sc ON sc.id=t.source_cluster_id
        LEFT JOIN clusters dc ON dc.id=t.destination_cluster_id
        ORDER BY t.created_at DESC LIMIT 10
      `),
    ]);

    const uniqueImages = await pool.query('SELECT COUNT(*) FROM images');

    res.json({
      total_clusters: parseInt(clusters.rows[0].count),
      total_nodes: parseInt(nodes.rows[0].count),
      total_images: parseInt(images.rows[0].count),
      unique_images: parseInt(uniqueImages.rows[0].count),
      transfer_stats_24h: transfers.rows[0],
      recent_transfers: recentTransfers.rows,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch dashboard stats' });
  }
});

export default router;
