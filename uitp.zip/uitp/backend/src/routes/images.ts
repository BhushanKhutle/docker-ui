import { Router, Response } from 'express';
import pool from '../db/pool';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();
router.use(authenticate);

// GET /images
router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { search, cluster_id } = req.query;
    let query = `
      SELECT 
        i.id, i.repository, i.tag, i.full_name, i.digest, i.size_bytes, i.created_date, i.created_at,
        COUNT(DISTINCT ni.node_id) as node_count,
        ARRAY_AGG(DISTINCT c.name) FILTER (WHERE c.name IS NOT NULL) as cluster_names,
        ARRAY_AGG(DISTINCT c.environment) FILTER (WHERE c.environment IS NOT NULL) as environments
      FROM images i
      LEFT JOIN node_images ni ON ni.image_id = i.id
      LEFT JOIN nodes n ON n.id = ni.node_id AND n.is_active = true
      LEFT JOIN clusters c ON c.id = n.cluster_id AND c.is_active = true
      WHERE 1=1
    `;
    const params: any[] = [];

    if (search) {
      params.push(`%${search}%`);
      query += ` AND i.full_name ILIKE $${params.length}`;
    }
    if (cluster_id) {
      params.push(cluster_id);
      query += ` AND c.id = $${params.length}`;
    }

    query += ' GROUP BY i.id ORDER BY i.repository, i.tag';
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: 'Failed to fetch images' });
  }
});

// GET /images/inventory - matrix view
router.get('/inventory', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const clustersResult = await pool.query(
      'SELECT id, name, environment FROM clusters WHERE is_active=true ORDER BY environment, name'
    );
    const clusters = clustersResult.rows;

    const imagesResult = await pool.query(`
      SELECT DISTINCT i.id, i.full_name, i.repository, i.tag, i.size_bytes
      FROM images i
      JOIN node_images ni ON ni.image_id = i.id
      JOIN nodes n ON n.id = ni.node_id AND n.is_active = true
      JOIN clusters c ON c.id = n.cluster_id AND c.is_active = true
      ORDER BY i.repository, i.tag
    `);

    const presenceResult = await pool.query(`
      SELECT DISTINCT i.id as image_id, c.id as cluster_id
      FROM images i
      JOIN node_images ni ON ni.image_id = i.id
      JOIN nodes n ON n.id = ni.node_id AND n.is_active = true
      JOIN clusters c ON c.id = n.cluster_id AND c.is_active = true
    `);

    const presenceMap: Record<string, Set<string>> = {};
    for (const row of presenceResult.rows) {
      if (!presenceMap[row.image_id]) presenceMap[row.image_id] = new Set();
      presenceMap[row.image_id].add(row.cluster_id);
    }

    const inventory = imagesResult.rows.map(img => ({
      ...img,
      presence: clusters.reduce((acc: Record<string, boolean>, c) => {
        acc[c.id] = presenceMap[img.id]?.has(c.id) || false;
        return acc;
      }, {})
    }));

    res.json({ clusters, inventory });
  } catch {
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// GET /images/:id/locations
router.get('/:id/locations', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const imgResult = await pool.query('SELECT * FROM images WHERE id=$1', [req.params.id]);
    if (!imgResult.rows[0]) {
      res.status(404).json({ error: 'Image not found' });
      return;
    }
    const image = imgResult.rows[0];

    const presentResult = await pool.query(`
      SELECT n.id as node_id, n.name as node_name, n.node_type,
        c.id as cluster_id, c.name as cluster_name, c.environment
      FROM node_images ni
      JOIN nodes n ON n.id = ni.node_id AND n.is_active = true
      JOIN clusters c ON c.id = n.cluster_id AND c.is_active = true
      WHERE ni.image_id = $1
    `, [req.params.id]);

    const allNodesResult = await pool.query(`
      SELECT n.id as node_id, n.name as node_name, n.node_type,
        c.id as cluster_id, c.name as cluster_name, c.environment
      FROM nodes n
      JOIN clusters c ON c.id = n.cluster_id AND c.is_active = true
      WHERE n.is_active = true
    `);

    const presentIds = new Set(presentResult.rows.map(r => r.node_id));
    const missingNodes = allNodesResult.rows.filter(n => !presentIds.has(n.node_id));

    res.json({
      image_id: image.id,
      image_name: image.full_name,
      present_nodes: presentResult.rows,
      missing_nodes: missingNodes,
    });
  } catch {
    res.status(500).json({ error: 'Failed to fetch image locations' });
  }
});

export default router;
